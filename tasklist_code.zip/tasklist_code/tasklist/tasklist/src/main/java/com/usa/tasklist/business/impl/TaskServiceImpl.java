package com.usa.tasklist.business.impl;

import com.usa.tasklist.business.ITaskService;
import com.usa.tasklist.entity.Task;
import com.usa.tasklist.repository.TaskRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class TaskServiceImpl implements ITaskService {

    @Autowired
    private TaskRepository repository;
    @Override
    public List<Task> getAll() {
        return repository.findAll();
    }

    @Override
    public Optional<Task> getTask(Long taskId) {
        return repository.findById(taskId);
    }

    @Override
    public Task save(Task task) {
        return repository.save(task);
    }

    @Override
    public Task updateTask(Task task) {
        Task existingTask = repository.findById(task.getId()).orElse(null);
        if (existingTask != null) {
            existingTask.setName(task.getName());
            existingTask.setCompleted(task.isCompleted());
            return repository.save(existingTask);
        }
        return task;
    }

    public boolean deleteTask(Long taskId) {
        Boolean aBoolean = getTask(taskId).map(user -> {
            repository.delete(user);
            return true;
        }).orElse(false);
        return aBoolean;
    }
}