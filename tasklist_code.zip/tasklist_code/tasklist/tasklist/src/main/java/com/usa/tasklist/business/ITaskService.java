package com.usa.tasklist.business;

import com.usa.tasklist.entity.Task;

import java.util.List;
import java.util.Optional;

public interface ITaskService {
    public List<Task> getAll();

    public Optional<Task> getTask(Long  taskId);

    public Task save(Task task);

    public Task updateTask(Task task);

    public boolean deleteTask(Long taskId);
}