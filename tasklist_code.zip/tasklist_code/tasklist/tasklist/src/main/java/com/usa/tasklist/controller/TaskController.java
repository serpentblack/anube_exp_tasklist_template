package com.usa.tasklist.controller;

import com.usa.tasklist.business.impl.TaskServiceImpl;
import com.usa.tasklist.entity.Task;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@RestController
@RequestMapping("/task")
public class TaskController {
    @Autowired
    private TaskServiceImpl negocio;

    @GetMapping("/all")
    public List<Task> getAll(){
        return negocio.getAll();
    }

    @PostMapping("/save")
    public Task save(@RequestBody Task task) {
        return negocio.save(task);
    }

    @PutMapping("/update")
    public Task updateTask(@RequestBody Task task) {
        return negocio.updateTask(task);
    }

    @DeleteMapping("/delete/{taskId}")
    public boolean deleteTask(@RequestBody Long taskId) {
        return negocio.deleteTask(taskId);
    }
}
